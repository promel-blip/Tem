Uinta Basin Type-Curve Package
=============================
- uinta_complete_v1.0.0.shtc : COMPLETE trained bundle (everything embedded).
  5-member deep-learning ensemble, 1,207 wells, DCA parameters,
  19 per-bench type-curve area assigners. Load with the shale_tc_app:
    from shale_tc import projectfile
    pj, _, _ = projectfile.open_project("uinta_complete_v1.0.0.shtc")
- uinta_area_monthlies.xlsx : 120-month oil/gas P50/P10/P90 per area (54 areas)
  + fitted modified-hyperbolic decline parameters (Qi, Di, b, Dmin).
- uinta_full_report.pdf : full study report (data, predictors, training, insights,
  type curves, EUR by bench).
- uinta_type_curves.xlsx : per-bench type-curve summary tables.

All volumes per 1,000 ft of lateral.
